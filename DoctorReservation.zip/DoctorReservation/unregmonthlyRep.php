<?php
$conn = mysqli_connect("localhost","root","","doctor");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  session_start();
?>
<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Doctor</title>
<!--[if lt IE 9]>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<!--
afflatus, a free CSS web template by ZyPOP (zypopwebtemplates.com/)

Download: http://zypopwebtemplates.com/

License: Creative Commons Attribution
//-->
<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
<link rel="stylesheet" href="styles.css" type="text/css" />
<style type="text/css">
 .error {color: #FF0000;}
 </style>
</head>

<body>

		<div id="sitename">
			<div class="width">
				<h1><a href="#">Doctor Reservation System</a></h1>
        <?PHP
              
                $name=$surname=$cellno=$staffno="";

               if(isset($_SESSION['email']))
                {


                  $email=$_SESSION['email'];

                  $query="select * FROM patient WHERE email='$email'";
                  $result=mysqli_query($conn,$query);
                  $rows=mysqli_num_rows($result);
                  while ($rows=mysqli_fetch_array($result)) {
                  
                    
                     $staffno = $_SESSION['patient_id']= $rows['patient_id']; 
                     $name = $_SESSION['name']= $rows['name'];  
                     $surname = $_SESSION['surname']= $rows['surname'];
                     //$dob = $_SESSION['dob']= $rows['dob']; 
                     $cellno = $_SESSION['cellno']=$rows['cellno'];
                     
                  
                  }
                }
                  ?>


				<nav>
					<ul>
        					<li><a href="Choose.php">Return</a></li>
        	    				
         	   				
          	  				
        				</ul>
				</nav>
	
				<div class="clear"></div>
			</div>
		</div>
		<header>
			<div class="width">
        

				<h2> Welcome to my Doctor Appointment Booking System!</h2>		
			</div>
		</header>
		<section id="body" class="width clear">
			<aside id="sidebar" class="column-left">
				<ul>
                	<li>
						<h4>Menu-Bar</h4>
                        <ul class="blocklist">
                          
                            <li><a href="logout.php">Log out</a></li>
                            
                        </ul>

					</li>	
					
					
				</ul>
			</aside>
			<section id="content" class="column-right">
                		
	    <article>
				<?PHP
              
                

               

                  

                  $query="SELECT uappointment.uAppoint_id as app_id,uappointment.Surname as PSurname,uappointment.Name as PName,uappointment.idNumber as id_no,uappointment.date as date,uappointment.time as time,uappointment.info as info,concat('Ref2020',uappointment.uAppoint_id) as ref,doctor.name as Dname,doctor.surname as Dsurname,doctor.doctor_type 
                  FROM uappointment,doctor 
                  WHERE  uappointment.doctor_id=doctor.doctor_id
                  and
                  date_format(uappointment.date,'%m') =date_format(sysdate(),'%m')";

                  $result=mysqli_query($conn,$query);
                  
                  $rows=mysqli_num_rows($result);
                  
                 
                  
                  if ($rows>0) {
                    
                    ?>
                     
                    <h3>Monthly Report For Phone Call Appointment</h3>
                   <th><p style="color: white;">
                                                <a class="button button-reversed" href="UnregDailyRep.php" >Daily-Report</a>   
                                                <a class="button button-reversed" href="unregweeklyRep.php" >Weekly-Report</a>
                                                <a class="button button-reversed" href="unregmonthlyRep.php" >Monthly-Report</a>
                                                
                                                <a class="button button-reversed" href="unregDb.php" >Return</a>
                   
                   
                   </p></th>
                    
                
                    <table cellspacing="0">
                    <tr>
                    
                    <th>Patient Surname</th>
                    <th>Patient Name</th>
                    <th>Id Number</th>
                    <th>Date and Time</th>
                    <th>Additional info</th>
                    <th>Reference No.</th>
                    
                    <th>Dr Name</th>
                    <th>Dr Specialisation</th>
                        
                    
                        <th></th>
                    </tr>
                    <?php
                    while ($rows=mysqli_fetch_array($result)) {
                  ?>
                    
                   
                    <tr>
                    
                    <td><?php echo $rows['PSurname'];?></td>
                    <td><?php echo $rows['PName'];?></td>
                    <td><?php echo $rows['id_no'];?></td>
                    <td><?php echo $rows['date']." ".$rows['time'];?></td>
                    <td><?php echo $rows['info'];?></td>
                    <td><?php echo $rows['ref'];?></td>
                    
                    
                    <td><?php echo $rows['Dname']." ".$rows['Dsurname'];?></td>
                    <td><?php echo $rows['doctor_type'];?></td>

                   
        
                
                    
                  
                   </tr>
                     <?php
                  
                    }
                    ?>
                    </table>
                    <?php
                  }else{
                    ?>
                    <h3>You don't have any Appointment(s)</h3>
                    <?php
                  }
                  
                
                  ?>
  
				
			</article>
		</section>

	</section>
	
		<footer class="clear">
			<div  class="width">
				<p class="left">&copy; 2020 sitename.</p>
				
			</div>
		</footer>
</body>
</html>
